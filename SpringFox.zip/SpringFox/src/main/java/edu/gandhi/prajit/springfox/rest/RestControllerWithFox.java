package edu.gandhi.prajit.springfox.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import edu.gandhi.prajit.springfox.rest.pojo.Quotes;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "RestControllerWithFox", tags = {"You.Can.Get.Quotes"})
public class RestControllerWithFox {
	private Map<String, List<String>> _Quotes = new HashMap<>();

	@GetMapping(value = "/getJokerQuotes")
	@ApiOperation(code = 200, produces = MediaType.APPLICATION_JSON_VALUE, nickname = "Joker Aka Jack Napier", notes = "${spring.quote.notes.getJokerQuotes}", 
		response = List.class, responseContainer = "List/Array", value = "edu.gandhi.prajit.springfox.rest.RestControllerWithFox.getJokerQuotes")
	public ResponseEntity<List<String>> getJokerQuotes() {
		_Quotes.computeIfAbsent("Joker", key -> new ArrayList<>())
				.add("If You Are Good At Something Never Do It For Free.");
		_Quotes.get("Joker").add("Nobody Panics When Things Go 'According To Plan'");
		return ResponseEntity.ok(_Quotes.get("Joker"));
	}

	@GetMapping(value = "/getBatsyQuotes")
	public ResponseEntity<List<String>> getBatsyQuotes() {
		_Quotes.computeIfAbsent("Batman", key -> new ArrayList<>())
				.add("It's Not Who I Am Underneath,But What I Do That Defines Me.");
		_Quotes.get("Batman").add("Everything's Impossible,Until Somebody Does It.");
		return ResponseEntity.ok(_Quotes.get("Batman"));
	}

	@Autowired
	private RestTemplate restTemplate;

	@PostMapping(value = "/getRandomQuote/{id}", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ApiResponses({ @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	public ResponseEntity<Quotes[]> getRandomQuote(
			@ApiParam(value = "Name Provided In Query String", example = "Prajit") @RequestParam("name") String name,
			@ApiParam(value = "Random Id Provided", example = "Rand007") @PathVariable(name = "id") String id) {
		return ResponseEntity.ok(restTemplate
				.getForObject("http://quotesondesign.com/wp-json/posts?filter[orderby]=rand", Quotes[].class));
	}
}
