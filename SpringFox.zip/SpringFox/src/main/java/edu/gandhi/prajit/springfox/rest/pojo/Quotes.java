package edu.gandhi.prajit.springfox.rest.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
@JsonIgnoreProperties(ignoreUnknown = true)
public class Quotes {
	@ApiModelProperty(name = "Id",notes="Unique Id For Quotes",required=true)
	@JsonProperty("ID")
	private String id;
	@ApiModelProperty(name = "Title")
	@JsonProperty("title")
	private String title;
	@JsonProperty("content")
	@ApiModelProperty(name = "Content")
	private String content;
	@JsonProperty("link")
	@ApiModelProperty(name = "Link")
	private String link;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}
}
