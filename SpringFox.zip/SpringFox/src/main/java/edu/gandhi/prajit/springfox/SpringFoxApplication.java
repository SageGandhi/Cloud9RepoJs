package edu.gandhi.prajit.springfox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFoxApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFoxApplication.class, args);
	}
}
